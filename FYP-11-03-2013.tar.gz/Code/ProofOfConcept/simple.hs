module Main where

f x = x * 2

main = do print $ (f 1)